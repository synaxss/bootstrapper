﻿using System;
using System.Net.Http;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {


        string ValidKey = "anything u want";

        Console.WriteLine("Please enter key before you can proceed pal");
        string enteredKey = Console.ReadLine();

        if (enteredKey != ValidKey)
        {
            Console.WriteLine("Ivalid Key");
            return;
        }


        Console.WriteLine("Valid Key! proceeding");





        Console.WriteLine("What do you want to load?");
        Console.WriteLine("1. anything u want");
        Console.WriteLine("2. Anything u want");
        Console.WriteLine("3. aNything u want");

        string input = Console.ReadLine();
        string fileName = "";
        string url = "";

        switch (input)
        {
            case "1":
                fileName = "1.exe";
                url = "https://example.com/anything.exe";
                break;
            case "2":
                fileName = "2.exe";
                url = "https://example.com/anything.exe";
                break;
            case "3":
                fileName = "3.exe";
                url = "https://example.com/anything.exe";
                break;
            default:
                Console.WriteLine("Invalid choice...");
                return;
        }

        Console.WriteLine($"Downloading '{fileName}'...");

     
        Thread loadingThread = new Thread(() =>
        {
            for (int i = 0; i < 20; i++)
            {
                Console.Write("=");
                Thread.Sleep(100);
            }
        });
        loadingThread.Start();


        using (HttpClient client = new HttpClient())
        {
            byte[] fileBytes = await client.GetByteArrayAsync(url);
            await File.WriteAllBytesAsync(fileName, fileBytes);
        }

        loadingThread.Join();
        Console.WriteLine("\nDownload complete!");

  

        Console.WriteLine($"The file '{fileName}' has been downloaded successfully.");
    }
}
