﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Compression;
using Newtonsoft.Json; 
using System.Diagnostics;

namespace bootstrapper
{
    public partial class Zyren : Form
    {
        private long _totalBytes;
        private long _downloadedBytes;

        public Zyren()
        {
            InitializeComponent();
        }

        private void guna2CircleButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2CircleButton2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private async void guna2Button1_Click(object sender, EventArgs e)
        {
            guna2HtmlLabel2.Text = "Checking update status...";

            string jsonUrl = "PASTEBIN OR WTV HERE GETS UPDATES AND CHANGELOGS FOR UR BOOTSTRAPPER OR WTV";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    string jsonContent = await client.GetStringAsync(jsonUrl);
                    dynamic jsonData = JsonConvert.DeserializeObject(jsonContent);

                    bool status = jsonData.Status;
                    string changelog = jsonData.Changelog;
                    string softwareVersion = jsonData.SoftwareVersion;

                    
                    guna2HtmlLabel2.Text = changelog;

                    string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    string changelogFilePath = Path.Combine(desktopPath, "changelog.txt");
                    File.WriteAllText(changelogFilePath, changelog); 

                   
                    string versionFileName = $"{softwareVersion}.txt";
                    string versionFilePath = Path.Combine(desktopPath, versionFileName);
                    File.WriteAllText(versionFilePath, $"SoftwareVersion: {softwareVersion}");

                    if (status)
                    {
                        guna2HtmlLabel2.Text = "Starting download...";

                        string repoUrl = "DOWNLOAD EXE DIRECTORY RIGHT HERE";
                        string tempZipPath = Path.Combine(desktopPath, "name this wtv u want the zip to be named");

                        using (var response = await client.GetAsync(repoUrl))
                        {
                            _totalBytes = response.Content.Headers.ContentLength ?? 0;
                            _downloadedBytes = 0;

                            byte[] buffer = new byte[65536];
                            using (var stream = await response.Content.ReadAsStreamAsync())
                            using (var fileStream = new FileStream(tempZipPath, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                int bytesRead;
                                while ((bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                                {
                                    await fileStream.WriteAsync(buffer, 0, bytesRead);
                                    _downloadedBytes += bytesRead;
                                }
                            }
                        }

                     
                        string extractPath = Path.Combine(desktopPath, "rename to wtv");
                        ZipFile.ExtractToDirectory(tempZipPath, extractPath);
                        File.Delete(tempZipPath);

                        guna2HtmlLabel2.Text = "Extraction complete!";
                    }
                    else
                    {
                        guna2HtmlLabel2.Text = "Update is not available. Please try again later.";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
                guna2HtmlLabel2.Text = "Download failed!";
            }
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            Process.Start(new ProcessStartInfo(desktopPath) { UseShellExecute = true });
            Process.Start("add ur discord here so it joins it ");
        }
    }
}
